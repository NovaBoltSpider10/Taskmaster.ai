import { Link, useLocation } from "react-router-dom";
import {
  FaTachometerAlt,
  FaCalendarAlt,
  FaUserFriends,
  FaChalkboardTeacher,
  FaCog,
  FaTasks,
  FaSignOutAlt,
} from "react-icons/fa";
import { SiFuturelearn } from "react-icons/si";
import { GrResources } from "react-icons/gr";
import type { IconType } from "react-icons";

interface NavItem {
  name: string;
  path: string;
  icon: IconType;
}

function Sidebar() {
  const location = useLocation();

  const navItems: NavItem[] = [
    { name: "Dashboard", path: "/dashboard", icon: FaTachometerAlt },
    { name: "Calendar", path: "/calendar", icon: FaCalendarAlt },
    { name: "Friends", path: "/friends", icon: FaUserFriends },
    { name: "Class Manager", path: "/classes", icon: FaChalkboardTeacher },
    { name: "Tasks", path: "/tasks", icon: FaTasks },
    { name: "FlashCards", path: "/flashcards", icon: SiFuturelearn },
    { name: "Resources", path: "/resources", icon: GrResources },
    { name: "Settings", path: "/settings", icon: FaCog },
  ];

  return (
    <div className="w-56 h-screen fixed top-0 left-0 bg-white shadow-xl flex flex-col justify-between z-20">
      {/* Top Section */}
      <div className="px-3 pt-4 pb-2">
        <Link to="/" className="flex items-center gap-2 mb-6 px-1">
          <img src="/school_work_1.svg" alt="Logo" className="w-8 h-8" />
          <span className="text-lg font-extrabold text-violet-800 tracking-tight">
            TaskMasterAI
          </span>
        </Link>

        {/* Navigation */}
        <nav className="space-y-5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.name}
                to={item.path}
                className={`flex items-center gap-4 px-2.5 py-2 rounded-md text-sm font-medium transition w-full
                ${
                  isActive
                    ? "bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-md"
                    : "text-slate-700 hover:bg-slate-100"
                }`}
              >
                <Icon size={16} className="min-w-[16px]" />
                <span className="flex-1">{item.name}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Logout Button */}
      <div className="px-3 pb-4">
        <button
          onClick={() => console.log("Logging out...")}
          className="w-full flex items-center gap-3 px-2.5 py-2 rounded-md bg-red-50 text-red-600 hover:bg-red-100 font-semibold text-sm transition"
        >
          <FaSignOutAlt size={15} />
          <span className="flex-1 text-left">Logout</span>
        </button>
      </div>
    </div>
  );
}

export default Sidebar;
